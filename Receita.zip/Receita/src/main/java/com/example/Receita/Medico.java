package com.example.Receita;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "medico")
@Entity(name = "medico")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class Medico extends Pessoa {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String crm;
	private String especialidade;
	public Medico(Long id, String nome, int idade, String cpf, String endereco, Long id2, String crm,
			String especialidade) {
		super(id, nome, idade, cpf, endereco);
		id = id2;
		this.crm = crm;
		this.especialidade = especialidade;
	}	
}
