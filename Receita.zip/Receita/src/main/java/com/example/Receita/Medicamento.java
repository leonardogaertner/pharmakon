package com.example.Receita;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "medicamento")
@Entity(name = "medicamento")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class Medicamento {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
   private String nome;
   private String bula;
   
public Medicamento(Long id, String nome, String bula) {
	this.id = id;
	this.nome = nome;
	this.bula = bula;
}   
}
