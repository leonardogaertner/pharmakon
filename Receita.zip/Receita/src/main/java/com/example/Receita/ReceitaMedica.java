package com.example.Receita;

import java.util.ArrayList;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "receitaMedica")
@Entity(name = "receitaMedica")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class ReceitaMedica {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String pacienteAtendido;
	private ArrayList<String> medicamentos = new ArrayList<>();
	private String assinaturaDigital;
	public ReceitaMedica(Long id, String pacienteAtendido, ArrayList<String> medicamentos, String assinaturaDigital) {
		this.id = id;
		this.pacienteAtendido = pacienteAtendido;
		this.medicamentos = medicamentos;
		this.assinaturaDigital = assinaturaDigital;
	}
	
	
}

