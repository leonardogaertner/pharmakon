package model;

import java.util.ArrayList;

public class ReceitaMedica {
	private String medicoResponsavel;
	private String pacienteAtendido;
	private ArrayList<String> medicamentos;
	private boolean assinaturaDigital;
	
	
	
	public ReceitaMedica(String medicoResponsavel, String pacienteAtendido, ArrayList<String> medicamentos,
			boolean assinaturaDigital) {
		super();
		this.medicoResponsavel = medicoResponsavel;
		this.pacienteAtendido = pacienteAtendido;
		this.medicamentos = medicamentos;
		this.assinaturaDigital = assinaturaDigital;
	}
	public ReceitaMedica() {
	}

	public String getMedicoResponsavel() {
		return medicoResponsavel;
	}
	public void setMedicoResponsavel(String medicoResponsavel) {
		this.medicoResponsavel = medicoResponsavel;
	}
	public String getPacienteAtendido() {
		return pacienteAtendido;
	}
	public void setPacienteAtendido(String pacienteAtendido) {
		this.pacienteAtendido = pacienteAtendido;
	}
	public ArrayList<String> getMedicamentos() {
		return medicamentos;
	}
	public void setMedicamentos(ArrayList<String> medicamentos) {
		this.medicamentos = medicamentos;
	}
	public boolean isAssinaturaDigital() {
		return assinaturaDigital;
	}
	public void setAssinaturaDigital(boolean assinaturaDigital) {
		this.assinaturaDigital = assinaturaDigital;
	}
	@Override
	public String toString() {
		return "Medico Responsavel: " + medicoResponsavel + ", Paciente Atendido: " + pacienteAtendido
				+ ", Medicamentos: " + medicamentos + ", Assinatura Digital: " + assinaturaDigital;
	}
	
	
	
	
}
