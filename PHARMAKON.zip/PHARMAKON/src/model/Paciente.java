package model;

public class Paciente extends Pessoa {
	private int registro;
	private String histórico;
	
	public Paciente(String nome, int idade, String cpf, String endereco, int registro, String histórico) {
		super(nome, idade, cpf, endereco);
		this.registro = registro;
		this.histórico = histórico;
	}
	
	public Paciente() {
	}

	public int getRegistro() {
		return registro;
	}

	public void setRegistro(int registro) {
		this.registro = registro;
	}

	public String getHistórico() {
		return histórico;
	}

	public void setHistórico(String histórico) {
		this.histórico = histórico;
	}

	@Override
	public String toString() {
		return "Registro: " + registro + ", histórico: " + histórico + ", Nome: " + getNome() + ", Idade: "
				+ getIdade() + ", Cpf: " + getCpf() + ", Endereco: " + getEndereco();
	}	
}
