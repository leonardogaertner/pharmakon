package model;

public class Medicamento {
	private String nome;
	private String bula;
	
	public Medicamento() {
	}
	
	public Medicamento(String nome, String bula) {
		this.nome = nome;
		this.bula = bula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getBula() {
		return bula;
	}

	public void setBula(String bula) {
		this.bula = bula;
	}
	
	
}
	

