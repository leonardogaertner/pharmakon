package model;

public class Medico extends Pessoa {
	private String crm;
	private String especialidade;
	
	public Medico(String nome, int idade, String cpf, String endereco, String crm, String especialidade) {
		super(nome, idade, cpf, endereco);
		this.crm = crm;
		this.especialidade = especialidade;
	}

	public Medico() {
	}

	public String getCrm() {
		return crm;
	}

	public void setCrm(String crm) {
		this.crm = crm;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}

	@Override
	public String toString() {
		return "Medico crm: " + crm + ", especialidade: " + especialidade + ", Nome: " + getNome() + ", Idade: "
				+ getIdade() + ", Cpf: " + getCpf() + ", Endereco: " + getEndereco();
	}
	
	
	
	
	

}
